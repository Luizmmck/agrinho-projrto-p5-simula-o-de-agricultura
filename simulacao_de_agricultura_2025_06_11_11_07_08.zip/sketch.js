// Variáveis do Jogo
let growth = 0;  // Crescimento da planta (0-100%)
let money = 0;   // Dinheiro do jogador
let weather = "Sol";  // Clima inicial
let plantState = "semeando";  // Estado da planta ("semeando", "plantada")
let time = 0;  // Contador de tempo para mudança de clima
let canvas;
let growthText;
let weatherText;
let moneyText;

// Função p5.js setup()
function setup() {
    // Cria o canvas do p5.js
    canvas = createCanvas(800, 600);
    canvas.parent('game-container'); // Coloca o canvas no div com id 'game-container'

    // Referências para os textos de UI
    growthText = select("#growthText");
    weatherText = select("#weatherText");
    moneyText = select("#moneyText");

    // Configuração dos botões de interação
    select("#plantButton").mousePressed(plant);
    select("#waterButton").mousePressed(water);
    select("#harvestButton").mousePressed(harvest);
    select("#sellButton").mousePressed(sell);
}

// Função p5.js draw()
function draw() {
    // Limpa a tela
    background(204, 255, 204);  // Fundo verde claro representando o campo

    // Desenha o solo
    fill(139, 69, 19);
    rect(0, height - 100, width, 100);  // Solo

    // Desenha a planta
    fill(34, 139, 34);
    if (growth > 0) {
        rect(375, height - 100 - growth, 50, growth); // Tronco da planta
    }

    // Desenha as folhas
    if (growth > 10) {
        fill(0, 100, 0);
        ellipse(400, height - 100 - growth, 80, 80); // Folhas
    }

    // Atualiza e exibe o texto de crescimento
    growthText.html(growth.toFixed(0) + "%");

    // Atualiza o clima e o dinheiro
    weatherText.html(weather);
    moneyText.html("R$ " + money.toFixed(2));

    // Atualiza o estado do clima e o crescimento da planta
    updateWeather();
    growPlant();
    time++;
}

// Função para simular o crescimento da planta
function growPlant() {
    if (plantState === "plantada") {
        if (weather === "Sol" && time % 3 === 0) {
            growth += 5;  // Cresce mais rápido com sol
        } else if (weather === "Chuva" && time % 2 === 0) {
            growth += 3;  // Cresce com chuva
        } else if (weather === "Nuvens" && time % 4 === 0) {
            growth += 2;  // Cresce lentamente com nuvens
        } else if (weather === "Vento" && time % 5 === 0) {
            growth -= 3;  // Enfraquece com vento
        }

        growth = constrain(growth, 0, 100); // Limitar crescimento entre 0 e 100
    }
}

// Função para atualizar o clima
function updateWeather() {
    if (time % 5 === 0) {
        const rand = floor(random(4));
        switch (rand) {
            case 0:
                weather = "Sol";
                break;
            case 1:
                weather = "Chuva";
                break;
            case 2:
                weather = "Nuvens";
                break;
            case 3:
                weather = "Vento";
                break;
        }
    }
}

// Função para plantar a planta
function plant() {
    if (plantState === "semeando") {
        plantState = "plantada";
        growth = 5;  // Começa com um pequeno crescimento
        alert("Planta semeada! Aguarde o crescimento.");
    }
}

// Função para regar a planta
function water() {
    if (plantState === "plantada") {
        if (weather === "Chuva") {
            growth += 10;  // Cresce mais rapidamente se estiver chovendo
        } else {
            growth += 5;  // Cresce de forma padrão
        }
        growth = constrain(growth, 0, 100);
        alert("Você regou a planta!");
    }
}

// Função para colher a planta
function harvest() {
    if (plantState === "plantada" && growth === 100) {
        alert("Planta colhida!");
        money += 10;  // Adiciona dinheiro pela colheita
        plantState = "semeando";  // Reseta o estado para "semeando"
        growth = 0;
    } else if (growth < 100) {
        alert("A planta ainda não está pronta para ser colhida.");
    }
}

// Função para vender as plantas na cidade
function sell() {
    if (money > 0) {
        alert("Você vendeu suas plantas e ganhou R$ " + money.toFixed(2));
        money = 0;  // Resetando o dinheiro após a venda
    } else {
        alert("Você não tem plantas para vender.");
    }
}

